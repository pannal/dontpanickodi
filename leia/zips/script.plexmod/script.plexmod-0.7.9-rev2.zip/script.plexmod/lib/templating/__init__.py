# coding=utf-8

from .render import render_templates
